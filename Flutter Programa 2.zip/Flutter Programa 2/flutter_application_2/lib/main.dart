import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const PositiveMessagesApp());
}

class PositiveMessagesApp extends StatelessWidget {
  const PositiveMessagesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mensagens Positivas',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4CAF50),
          primary: const Color(0xFF4CAF50),
          secondary: const Color(0xFF2196F3),
          background: const Color(0xFFF5F5F5),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            fontSize: 24.0,
            fontWeight: FontWeight.w700,
            color: Colors.black87,
          ),
          bodyLarge: TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.w400,
            color: Colors.black87,
            height: 1.5,
          ),
        ),
      ),
      home: const PositiveMessagesScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class PositiveMessagesScreen extends StatefulWidget {
  const PositiveMessagesScreen({super.key});

  @override
  State<PositiveMessagesScreen> createState() => _PositiveMessagesScreenState();
}

class _PositiveMessagesScreenState extends State<PositiveMessagesScreen> {
  final Random _random = Random();
  final List<String> _positiveMessages = [
    'Acredite em si mesmo e tudo será possível.',
    'Respire fundo: hoje é um bom dia para recomeçar.',
    'Pequenos passos também te levam longe.',
    'Gratidão muda a forma como vemos o mundo.',
    'Faça o melhor que puder, com o que tem hoje.',
    'Sua luz inspira outras pessoas.',
    'Cuide de você com carinho.',
    'Permita-se aprender com calma.',
    'Você já venceu muitos dias difíceis.',
    'Escolha pensamentos que te façam bem.',
  ];

  String _currentMessage = '';
  int _currentIndex = 0;
  int _previousIndex = -1;

  @override
  void initState() {
    super.initState();
    _generateNewMessage();
  }

  void _generateNewMessage() {
    setState(() {
      int newIndex;
      // Garante que não repita a mensagem anterior
      do {
        newIndex = _random.nextInt(_positiveMessages.length);
      } while (newIndex == _previousIndex && _positiveMessages.length > 1);
      
      _previousIndex = _currentIndex;
      _currentIndex = newIndex;
      _currentMessage = _positiveMessages[_currentIndex];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Mensagens Positivas',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 20.0,
          ),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.9),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: Stack(
        children: [
          // Imagem de fundo
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80',
                ),
                // Para usar imagem local descomente a linha abaixo:
                // image: AssetImage('assets/background.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),

          // Overlay escuro para melhor contraste
          Container(
            color: Colors.black.withOpacity(0.2),
          ),

          // Conteúdo principal
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo/Ícone
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.auto_awesome,
                      size: 50,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Cartão com efeito de vidro
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20.0),
                    child: BackdropFilter(
                      filter: const ColorFilter.mode(
                        Colors.white,
                        BlendMode.srcOver,
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(32.0),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(20.0),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.3),
                            width: 1.0,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Mensagem positiva
                            Text(
                              _currentMessage,
                              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                    fontStyle: FontStyle.italic,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                              textAlign: TextAlign.center,
                            ),

                            const SizedBox(height: 20),

                            // Indicador de progresso
                            Text(
                              '${_currentIndex + 1} de ${_positiveMessages.length}',
                              style: const TextStyle(
                                fontSize: 14.0,
                                color: Colors.grey,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Botão com StadiumBorder
                  ElevatedButton(
                    onPressed: _generateNewMessage,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 18,
                      ),
                      shape: const StadiumBorder(),
                      elevation: 4,
                      shadowColor: Colors.black.withOpacity(0.3),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.refresh, size: 20),
                        SizedBox(width: 10),
                        Text(
                          'Nova Mensagem',
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Texto inspirador
                  Text(
                    '✨ Sua dose diária de positividade ✨',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14.0,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}