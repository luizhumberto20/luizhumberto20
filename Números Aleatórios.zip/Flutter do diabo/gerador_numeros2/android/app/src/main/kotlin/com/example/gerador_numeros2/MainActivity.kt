package com.example.gerador_numeros2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
