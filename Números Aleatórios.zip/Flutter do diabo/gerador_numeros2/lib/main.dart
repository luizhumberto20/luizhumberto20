import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gerador Aleatório',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.purple),
        useMaterial3: true,
      ),
      home: const RandomGeneratorScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RandomGeneratorScreen extends StatefulWidget {
  const RandomGeneratorScreen({super.key});

  @override
  State<RandomGeneratorScreen> createState() => _RandomGeneratorScreenState();
}

class _RandomGeneratorScreenState extends State<RandomGeneratorScreen> {
  final Random _random = Random();
  final List<String> _imageUrls = [
    'https://picsum.photos/300/300?random=1',
    'https://picsum.photos/300/300?random=2',
    'https://picsum.photos/300/300?random=3',
    'https://picsum.photos/300/300?random=4',
    'https://picsum.photos/300/300?random=5',
    'https://picsum.photos/300/300?random=6',
    'https://picsum.photos/300/300?random=7',
    'https://picsum.photos/300/300?random=8',
    'https://picsum.photos/300/300?random=9',
    'https://picsum.photos/300/300?random=10',
  ];

  final List<Color> _colorPalette = [
    Colors.red,
    Colors.pink,
    Colors.purple,
    Colors.deepPurple,
    Colors.indigo,
    Colors.blue,
    Colors.lightBlue,
    Colors.cyan,
    Colors.teal,
    Colors.green,
    Colors.lightGreen,
    Colors.lime,
    Colors.yellow,
    Colors.amber,
    Colors.orange,
    Colors.deepOrange,
    Colors.brown,
    Colors.blueGrey,
  ];

  int _randomNumber = 0;
  String _currentImageUrl = '';
  bool _isLoadingImage = false;
  Color _currentNumberColor = Colors.purpleAccent;
  Color _currentImageCardColor = Colors.blue;
  Color _currentNumberCardColor = Colors.purple;
  Color _currentBackgroundColor = Colors.white;
  Color _currentTextColor = Colors.black;

  @override
  void initState() {
    super.initState();
    // Gerar número, imagem e cores iniciais
    _generateRandomNumber();
    _generateRandomImage();
    _generateRandomColors();
  }

  void _generateRandomNumber() {
    setState(() {
      _randomNumber = _random.nextInt(1000) + 1;
      _generateRandomNumberColor();
    });
  }

  void _generateRandomNumberColor() {
    setState(() {
      _currentNumberColor = _colorPalette[_random.nextInt(_colorPalette.length)];
    });
  }

  Future<void> _generateRandomImage() async {
    setState(() {
      _isLoadingImage = true;
    });

    await Future.delayed(const Duration(milliseconds: 300));

    setState(() {
      _currentImageUrl = _imageUrls[_random.nextInt(_imageUrls.length)];
      _isLoadingImage = false;
    });
  }

  void _generateRandomColors() {
    setState(() {
      _currentNumberCardColor = _colorPalette[_random.nextInt(_colorPalette.length)];
      _currentImageCardColor = _colorPalette[_random.nextInt(_colorPalette.length)];
      _currentBackgroundColor = _colorPalette[_random.nextInt(_colorPalette.length)].withOpacity(0.1);
      _currentTextColor = _getContrastColor(_currentBackgroundColor);
      _generateRandomNumberColor();
    });
  }

  Color _getContrastColor(Color backgroundColor) {
    // Calcula o brilho da cor de fundo para escolher texto preto ou branco
    final brightness = ThemeData.estimateBrightnessForColor(backgroundColor);
    return brightness == Brightness.dark ? Colors.white : Colors.black;
  }

  void _generateBoth() {
    _generateRandomNumber();
    _generateRandomImage();
    _generateRandomColors();
  }

  void _generateOnlyColors() {
    _generateRandomColors();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _currentBackgroundColor,
      appBar: AppBar(
        title: const Text('Gerador Aleatório'),
        backgroundColor: _currentNumberCardColor.withOpacity(0.8),
        foregroundColor: _getContrastColor(_currentNumberCardColor),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Seção do Número Aleatório
            Card(
              elevation: 6,
              color: _currentNumberCardColor.withOpacity(0.9),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text(
                      'Número Aleatório',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: _getContrastColor(_currentNumberCardColor),
                          ),
                    ),
                    const SizedBox(height: 15),
                    Text(
                      '$_randomNumber',
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: _currentNumberColor,
                            shadows: [
                              Shadow(
                                color: Colors.black.withOpacity(0.3),
                                blurRadius: 4,
                                offset: const Offset(2, 2),
                              ),
                            ],
                          ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _generateRandomNumber,
                            icon: const Icon(Icons.numbers),
                            label: const Text('Gerar Número'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _getContrastColor(_currentNumberCardColor),
                              foregroundColor: _currentNumberCardColor,
                              minimumSize: const Size(0, 50),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        IconButton(
                          onPressed: _generateRandomNumberColor,
                          icon: const Icon(Icons.color_lens),
                          style: IconButton.styleFrom(
                            backgroundColor: _getContrastColor(_currentNumberCardColor),
                            foregroundColor: _currentNumberCardColor,
                            minimumSize: const Size(50, 50),
                          ),
                          tooltip: 'Mudar cor do número',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // Seção da Imagem Aleatória
            Card(
              elevation: 6,
              color: _currentImageCardColor.withOpacity(0.9),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text(
                      'Imagem Aleatória',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: _getContrastColor(_currentImageCardColor),
                          ),
                    ),
                    const SizedBox(height: 15),

                    // Container para a imagem
                    Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                        border: Border.all(
                          color: _currentImageCardColor,
                          width: 3,
                        ),
                      ),
                      child: _isLoadingImage
                          ? Center(
                              child: CircularProgressIndicator(
                                color: _currentImageCardColor,
                              ),
                            )
                          : _currentImageUrl.isEmpty
                              ? Center(
                                  child: Icon(
                                    Icons.image,
                                    size: 50,
                                    color: _currentImageCardColor,
                                  ),
                                )
                              : ClipRRect(
                                  borderRadius: BorderRadius.circular(9),
                                  child: Image.network(
                                    _currentImageUrl,
                                    fit: BoxFit.cover,
                                    loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                      if (loadingProgress == null) return child;
                                      return Center(
                                        child: CircularProgressIndicator(
                                          value: loadingProgress.expectedTotalBytes != null
                                              ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                              : null,
                                          color: _currentImageCardColor,
                                        ),
                                      );
                                    },
                                    errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                                      return Center(
                                        child: Icon(
                                          Icons.error,
                                          color: _currentImageCardColor,
                                          size: 50,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                    ),

                    const SizedBox(height: 20),

                    ElevatedButton.icon(
                      onPressed: _generateRandomImage,
                      icon: const Icon(Icons.image),
                      label: const Text('Gerar Imagem'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _getContrastColor(_currentImageCardColor),
                        foregroundColor: _currentImageCardColor,
                        minimumSize: const Size(double.infinity, 50),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // Botão para gerar cores
            ElevatedButton.icon(
              onPressed: _generateOnlyColors,
              icon: const Icon(Icons.palette),
              label: const Text('Mudar Cores'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 55),
              ),
            ),

            const SizedBox(height: 15),

            // Botão para gerar tudo
            ElevatedButton.icon(
              onPressed: _generateBoth,
              icon: const Icon(Icons.autorenew),
              label: const Text('Gerar Tudo Aleatório'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 55),
              ),
            ),

            const SizedBox(height: 10),

            // Informações sobre as cores
            Card(
              color: Colors.black.withOpacity(0.1),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text(
                  '💡 Dica: Use os botões para mudar cores individualmente!',
                  style: TextStyle(
                    color: _currentTextColor,
                    fontSize: 12,
                    fontStyle: FontStyle.italic,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),

      // Botão flutuante para cores
      floatingActionButton: FloatingActionButton(
        onPressed: _generateOnlyColors,
        backgroundColor: _currentNumberCardColor,
        foregroundColor: _getContrastColor(_currentNumberCardColor),
        child: const Icon(Icons.color_lens),
        tooltip: 'Mudar todas as cores',
      ),
    );
  }
}